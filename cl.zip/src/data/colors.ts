const pallete = {
    "pallete1": {
        color1: "#070D59",
        color2:"#070D59"
    }
}

export { pallete }
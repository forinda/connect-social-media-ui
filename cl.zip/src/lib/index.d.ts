declare module '*.module.scss' {
	const className: { [s: string]: string };
	export default className;
}
